combi :: (String, String) -> String
combi (first, second) = first ++ second
