mult x y = x * y
double = mult 2
